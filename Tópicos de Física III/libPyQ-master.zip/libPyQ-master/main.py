import rdmg; rdmg.test()
#import discord; discord.test()
