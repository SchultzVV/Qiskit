from math import atan


def pi():
    return 4*atan(1)
